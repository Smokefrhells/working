<?php
require_once '../../system/system.php';
include_once __DIR__ . '/sett.php';
include_once __DIR__ . '/WapkassaClass.php';

try {
    // Инициализация класса с id сайта и секретным ключом
    $wapkassa = new WapkassaClass(WK_ID, WK_SECRET);

    // Проверка обработчика (PING)
    if ($wapkassa->ping($_POST)) {
        // возврат успешной проверки
        echo $wapkassa->successPing();
    } else {
        // Парсинг входящих параметров
        $params = $wapkassa->parseRequest($_POST);

        $params['id']; // id платежа в системе wapkassa
        $params['site_id']; // id площадки
        $params['time']; // время оплаты в unixtime
        $params['comm']; // комментарий платежа
        $params['amount']; // сумма платежа
        $params['add']; // массив с допольнительными параметрами

        // собственный код зачисления платежа на сайте
        if ($params['add']['type'] == 'gold' && !empty($wk_cena_gold[$params['add']['count']]) && $wk_cena_gold[$params['add']['count']] <= $params['amount']) {

$gold =  $params['add']['count'];       
	
 #-Акция на x2 золото-#
$sel_stock_2 = $pdo->query("SELECT * FROM `stock` WHERE `type` = 2");
if($sel_stock_2-> rowCount() != 0){
$bonus_gold = $gold*2;
}
#-Акция на x3 золото-#
$sel_stock_3 = $pdo->query("SELECT * FROM `stock` WHERE `type` = 3");
if($sel_stock_3-> rowCount() != 0){
$bonus_gold = $gold*3;
}
#-Зачисление золота-#
$upd_users = $pdo->prepare("UPDATE `users` SET `gold` = `gold` + :gold WHERE `id` = :id LIMIT 1");
$upd_users->execute(array(':gold' => $gold+$bonus_gold, ':id' => $params['add']['user_id']));
			
#-Питомец в подарок-#
$sel_stock_8 = $pdo->query("SELECT * FROM `stock` WHERE `type` = 8");
if($sel_stock_8-> rowCount() != 0 and ($gold >= 750 or $gold >= 1500)){
if($gold >= 750){
$pets_id = 4;
$pets_name = 'Змееглав';	
}
if($gold >= 1500){	
$pets_id = 5;
$pets_name = 'Гелаус';
}
#-Запись питомца-#
$ins_pets_me = $pdo->prepare("INSERT INTO `pets_me` SET `pets_id` = :pets_id, `user_id` = :user_id");
$ins_pets_me->execute(array(':pets_id' => $pets_id, ':user_id' => $params['add']['user_id']));
}


$sel_donat = $pdo->prepare("SELECT * FROM `donat` WHERE `gold` = :gold AND `user_id` = :user_id");
$sel_donat->execute(array(':gold' => $params['add']['count'], ':user_id' => $params['add']['user_id']));
if($sel_donat->rowCount() != 0){	
$upd_donat = $pdo->prepare("UPDATE `donat` SET `statys` = 1 WHERE `gold` = :gold AND `user_id` = :user_id LIMIT 1");	
$upd_donat->execute(array(':gold' => $params['add']['count'], ':user_id' => $params['add']['user_id']));	
}
}

        // возврат успешной обработки
        echo $wapkassa->successPayment();
    }
} catch (Exception $e) {
    // вывод ошибки
    echo 'Ошибка: ' . $e->getMessage() . PHP_EOL;
}

?>